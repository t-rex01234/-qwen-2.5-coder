import { useEffect, useRef, useState } from 'react'
import * as THREE from 'three'
import {
  Activity, ArrowDown, ArrowUpRight, Bot, Box, Braces, Check, ChevronDown,
  ChevronRight, CircleHelp, Cloud, Code2, Command, Cpu, Download, FileCode2,
  FileImage, Folder, Gamepad2, Gauge, Globe2, Layers3, Link2, Loader2,
  Maximize2, MessageSquare, MoreHorizontal, Play, Plus, Rocket, Send,
  Settings2, ShieldCheck, Sparkles, Terminal, WandSparkles, Wifi, X
} from 'lucide-react'

type Mode = '2D' | '2.5D' | '3D'
type Message = { role: 'user' | 'assistant'; content: string }

const starterCode = `// Welcome to GameForge AI
// Ask Qwen to generate a game, then review the code here.

const game = {
  title: "Crystal Runner",
  genre: "2D Platformer",
  controls: ["A / D: Move", "Space: Jump"],
  objective: "Collect 5 crystals"
};

function updateGame(deltaTime) {
  // Your game logic goes here.
}
`

function ThreePreview() {
  const mountRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const host = mountRef.current
    if (!host) return
    const scene = new THREE.Scene()
    scene.background = new THREE.Color('#111827')
    scene.fog = new THREE.Fog('#111827', 9, 24)
    const camera = new THREE.PerspectiveCamera(48, host.clientWidth / 300, 0.1, 100)
    camera.position.set(5, 4, 7)
    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setSize(host.clientWidth, 300)
    host.appendChild(renderer.domElement)
    scene.add(new THREE.HemisphereLight(0xb8d7ff, 0x29203f, 2))
    const light = new THREE.DirectionalLight(0xffffff, 2.5)
    light.position.set(4, 8, 5); scene.add(light)
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ color: '#26364a', roughness: 0.9 }))
    floor.rotation.x = -Math.PI / 2; floor.position.y = -0.8; scene.add(floor)
    const island = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 3.4, 0.65, 7), new THREE.MeshStandardMaterial({ color: '#385c65', roughness: 0.8 }))
    island.position.y = -0.45; scene.add(island)
    const crystalMat = new THREE.MeshStandardMaterial({ color: '#8c7cff', emissive: '#4433aa', emissiveIntensity: 1.2, metalness: 0.2, roughness: 0.25 })
    for (let i = 0; i < 5; i++) {
      const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.34 + (i % 2) * 0.12), crystalMat)
      const a = i * Math.PI * 2 / 5
      crystal.position.set(Math.cos(a) * 1.7, 0.35, Math.sin(a) * 1.7)
      scene.add(crystal)
    }
    const player = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.55, 4, 8), new THREE.MeshStandardMaterial({ color: '#f5b86b', roughness: 0.45 }))
    player.position.set(0, 0.15, 0); scene.add(player)
    let frame = 0
    let raf = 0
    const animate = () => {
      frame += 0.008
      player.position.y = 0.15 + Math.sin(frame * 2) * 0.12
      island.rotation.y += 0.0008
      renderer.render(scene, camera)
      raf = requestAnimationFrame(animate)
    }
    animate()
    const resize = () => {
      if (!host) return
      camera.aspect = host.clientWidth / 300
      camera.updateProjectionMatrix()
      renderer.setSize(host.clientWidth, 300)
    }
    window.addEventListener('resize', resize)
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); renderer.dispose(); host.removeChild(renderer.domElement) }
  }, [])
  return <div className="three-mount" ref={mountRef} />
}

function Preview({ mode }: { mode: Mode }) {
  if (mode === '3D') return <ThreePreview />
  if (mode === '2.5D') return <div className="preview-25">
    <div className="sun-glow" /><div className="mountain m1" /><div className="mountain m2" />
    <div className="platform p1" /><div className="platform p2" />
    <div className="hero-25"><span /></div>
    <div className="gem g1" /><div className="gem g2" /><div className="gem g3" />
    <div className="preview-hint">A tiny world, ready to explore</div>
  </div>
  return <div className="preview-2d">
    <div className="cloud cloud-a" /><div className="cloud cloud-b" />
    <div className="platform-2d" />
    <div className="player-2d"><i /></div>
    <div className="coin coin-a" /><div className="coin coin-b" /><div className="coin coin-c" />
    <div className="hud-demo"><span>✦  03 / 05</span><span>♥ ♥ ♥</span></div>
    <div className="preview-hint">Collect the crystals</div>
  </div>
}

export default function App() {
  const [mode, setMode] = useState<Mode>('2D')
  const [code, setCode] = useState(starterCode)
  const [prompt, setPrompt] = useState('')
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Welcome to GameForge AI. Describe the game you want to create. I can help plan the architecture, write code, and iterate with you.' }
  ])
  const [apiUrl, setApiUrl] = useState('')
  const [apiToken, setApiToken] = useState('')
  const [showConnection, setShowConnection] = useState(false)
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState('Not connected')
  const [activeTab, setActiveTab] = useState<'code' | 'files' | 'assets'>('code')
  const [streamText, setStreamText] = useState('')
  const [error, setError] = useState('')

  async function sendPrompt() {
    if (!prompt.trim() || busy) return
    const userText = prompt.trim()
    setPrompt('')
    setError('')
    setMessages(prev => [...prev, { role: 'user', content: userText }])
    setBusy(true); setStreamText('')
    try {
      const base = apiUrl.trim().replace(/\/+$/, '')
      if (!base) throw new Error('Add your Colab or backend URL in Connection first.')
      const response = await fetch(`${base}/api/chat/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiToken}` },
        body: JSON.stringify({ prompt: userText, max_new_tokens: 900 })
      })
      if (!response.ok) {
        const body = await response.json().catch(() => ({}))
        throw new Error(body.detail || `Request failed (${response.status})`)
      }
      if (!response.body) throw new Error('Streaming is not available in this browser.')
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let full = ''
      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value, { stream: true })
        for (const line of chunk.split('\n')) {
          if (line.startsWith('data: ')) {
            const payload = line.slice(6)
            if (payload === '[DONE]') continue
            try {
              const item = JSON.parse(payload)
              if (item.token) { full += item.token; setStreamText(full) }
              if (item.error) throw new Error(item.error)
            } catch (e) {
              if (e instanceof Error && e.message !== 'Unexpected end of JSON input') throw e
            }
          }
        }
      }
      setMessages(prev => [...prev, { role: 'assistant', content: full || 'The model returned an empty response.' }])
      setStreamText('')
      setStatus('Connected')
    } catch (e) {
      const message = e instanceof Error ? e.message : 'Unknown connection error'
      setError(message)
      setMessages(prev => [...prev, { role: 'assistant', content: `Connection issue: ${message}` }])
    } finally { setBusy(false) }
  }

  async function testConnection() {
    try {
      const base = apiUrl.trim().replace(/\/+$/, '')
      const res = await fetch(`${base}/health`, { headers: { Authorization: `Bearer ${apiToken}` } })
      if (!res.ok) throw new Error(`Health check failed (${res.status})`)
      const data = await res.json()
      setStatus(data.model_loaded ? 'Connected · Model ready' : 'Connected · Model not loaded')
      setError('')
    } catch (e) {
      setStatus('Connection failed')
      setError(e instanceof Error ? e.message : 'Could not connect')
    }
  }

  function exportCode() {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'gameforge-project.js'; a.click()
    URL.revokeObjectURL(url)
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Gamepad2 size={21}/></div><div><strong>GAMEFORGE<span> AI</span></strong><small>CREATION STUDIO</small></div></div>
      <button className="new-project"><Plus size={16}/> New project <span>⌘ K</span></button>
      <div className="side-label">WORKSPACE</div>
      <button className="nav-item active"><Layers3 size={17}/> Studio</button>
      <button className="nav-item"><Folder size={17}/> My projects</button>
      <button className="nav-item"><FileImage size={17}/> Asset library</button>
      <div className="side-label side-label-spaced">TOOLS</div>
      <button className="nav-item"><Bot size={17}/> AI agents <span className="tiny-pill">BETA</span></button>
      <button className="nav-item"><Braces size={17}/> Code workspace</button>
      <button className="nav-item"><Activity size={17}/> Build & tests</button>
      <div className="sidebar-bottom">
        <div className="compute-card"><div className="compute-title"><span className="pulse-dot"/> COMPUTE STATUS</div><strong>Colab connection</strong><small>{status}</small><button onClick={() => setShowConnection(true)}><Link2 size={13}/> Configure connection</button></div>
        <button className="nav-item"><CircleHelp size={17}/> Help center</button>
        <div className="profile"><div className="avatar">G</div><div><strong>GameForge Workspace</strong><small>Free development</small></div><MoreHorizontal size={17}/></div>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14}/><strong>Untitled project</strong><span className="draft-tag">DRAFT</span></div>
        <div className="top-actions"><div className="save-state"><span className="pulse-dot"/> All changes saved</div><button className="icon-btn" title="Connection" onClick={() => setShowConnection(true)}><Cloud size={17}/></button><button className="share-btn" onClick={exportCode}><Download size={15}/> Export</button><div className="avatar small-avatar">G</div></div>
      </header>

      <div className="page-content">
        <section className="welcome-row">
          <div><div className="eyebrow"><Sparkles size={13}/> YOUR AI GAME DEVELOPMENT PARTNER</div><h1>Turn ideas into <em>playable worlds.</em></h1><p>Design, build, preview, and refine your next game with an AI coding partner.</p></div>
          <div className="engine-status"><span className="status-icon"><Cpu size={18}/></span><div><small>AI ENGINE</small><strong>Qwen2.5 Coder · 7B</strong><small className="muted">4-bit · Google Colab</small></div><ChevronDown size={15}/></div>
        </section>

        <section className="studio-grid">
          <div className="panel preview-panel">
            <div className="panel-head"><div className="panel-title"><div className="panel-icon purple"><Gamepad2 size={16}/></div><div><strong>Game preview</strong><small>Interactive scene preview</small></div></div><div className="preview-actions"><div className="mode-switch">{(['2D','2.5D','3D'] as Mode[]).map(m => <button key={m} className={mode===m?'selected':''} onClick={()=>setMode(m)}>{m}</button>)}</div><button className="icon-btn" title="Preview options"><Maximize2 size={15}/></button></div></div>
            <Preview mode={mode}/>
            <div className="preview-footer"><span><span className="live-dot"/> LIVE PREVIEW DEMO</span><span>1280 × 720 <Maximize2 size={12}/></span></div>
          </div>

          <div className="panel assistant-panel">
            <div className="panel-head"><div className="panel-title"><div className="panel-icon violet"><WandSparkles size={16}/></div><div><strong>AI game architect</strong><small>Describe what you want to build</small></div></div><button className="icon-btn"><MoreHorizontal size={17}/></button></div>
            <div className="chat-messages">
              {messages.map((m,i)=><div className={`message ${m.role}`} key={i}><div className="message-avatar">{m.role==='assistant'?<Sparkles size={14}/>:<span>Y</span>}</div><div className="message-content"><small>{m.role==='assistant'?'GAMEFORGE AI':'YOU'}</small><p>{m.content}</p></div></div>)}
              {busy && <div className="message assistant"><div className="message-avatar"><Loader2 size={14} className="spin"/></div><div className="message-content"><small>QWEN IS THINKING</small><p>{streamText || 'Connecting to your model…'}</p></div></div>}
            </div>
            {error && <div className="inline-error"><ShieldCheck size={14}/>{error}</div>}
            <div className="prompt-box"><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendPrompt()}}} placeholder="Describe your game idea… (Enter to send)" rows={3}/><div className="prompt-bottom"><span><Sparkles size={13}/> AI can make mistakes. Review generated code.</span><button className="send-btn" onClick={sendPrompt} disabled={busy || !prompt.trim()}>{busy?<Loader2 size={15} className="spin"/>:<Send size={15}/>}</button></div></div>
          </div>
        </section>

        <section className="panel code-panel">
          <div className="panel-head code-head"><div className="panel-title"><div className="panel-icon blue"><Code2 size={16}/></div><div><strong>Development workspace</strong><small>Inspect and edit your project files</small></div></div><div className="code-tools"><button className={`tab-btn ${activeTab==='code'?'active-tab':''}`} onClick={()=>setActiveTab('code')}><FileCode2 size={14}/> Code</button><button className={`tab-btn ${activeTab==='files'?'active-tab':''}`} onClick={()=>setActiveTab('files')}><Folder size={14}/> Files</button><button className={`tab-btn ${activeTab==='assets'?'active-tab':''}`} onClick={()=>setActiveTab('assets')}><FileImage size={14}/> Assets</button><button className="export-btn" onClick={exportCode}><Download size={14}/> Export file</button></div></div>
          {activeTab==='code' ? <div className="editor-wrap"><div className="editor-gutter">1<br/>2<br/>3<br/>4<br/>5<br/>6<br/>7<br/>8<br/>9<br/>10</div><textarea className="code-editor" spellCheck={false} value={code} onChange={e=>setCode(e.target.value)} /></div> : <div className="empty-tab"><div className="empty-icon">{activeTab==='files'?<Folder/>:<FileImage/>}</div><strong>{activeTab==='files'?'Project files':'Asset library'}</strong><p>Your generated {activeTab} will appear here as the project workflow is connected.</p></div>}
        </section>

        <footer className="footer"><span>GAMEFORGE AI <span className="footer-dot">•</span> CREATION STUDIO</span><span><ShieldCheck size={13}/> Private workspace · Review before running generated code</span><span>v0.1.0 starter</span></footer>
      </div>
    </main>

    {showConnection && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowConnection(false)}}><div className="connection-modal"><div className="modal-head"><div><div className="eyebrow"><Wifi size={13}/> MODEL CONNECTION</div><h2>Connect your AI engine</h2><p>Paste the temporary HTTPS URL and token printed by your Colab notebook.</p></div><button className="icon-btn" onClick={()=>setShowConnection(false)}><X size={18}/></button></div><label>Backend URL<input value={apiUrl} onChange={e=>setApiUrl(e.target.value)} placeholder="https://your-temporary-tunnel.trycloudflare.com"/></label><label>Private API token<input type="password" value={apiToken} onChange={e=>setApiToken(e.target.value)} placeholder="Paste the token from Colab"/></label><div className="security-note"><ShieldCheck size={15}/> Token is held in page memory only and cleared when you refresh. Never share it.</div><div className="modal-actions"><button className="secondary-btn" onClick={()=>setShowConnection(false)}>Cancel</button><button className="primary-btn" onClick={async()=>{await testConnection();}}>Test connection <ArrowUpRight size={15}/></button></div><small className="connection-status">{status}</small></div></div>}
  </div>
}
