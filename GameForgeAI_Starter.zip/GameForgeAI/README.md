# GameForge AI — Starter Platform

A premium React + FastAPI starter for a game-development AI workspace, with a Google Colab notebook for running Qwen2.5-Coder-7B-Instruct in 4-bit mode.

## What is included

- React + TypeScript + Vite frontend
- FastAPI backend with bearer-token protection
- Streaming text generation from Qwen through Hugging Face Transformers
- 2D Canvas, 2.5D CSS scene, and 3D Three.js preview demos
- Google Colab notebook to run the backend and expose a temporary Cloudflare Tunnel
- No automatic execution of model-generated code

## Requirements

- Node.js 20 or newer recommended
- Python 3.10+
- Google account for Colab
- Colab GPU runtime (T4 may be available, not guaranteed)

## 1. Run the frontend locally

Open a terminal in the project folder:

```bash
cd frontend
npm install
npm run dev
```

Open the URL printed by Vite, normally `http://localhost:5173`.

## 2. Run the backend locally (optional)

Create a virtual environment and install dependencies:

```bash
cd backend
python -m venv .venv
```

Windows:
```powershell
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Set an API token (Windows PowerShell):
```powershell
$env:GAMEFORGE_API_TOKEN="replace-with-a-long-random-secret"
$env:CORS_ORIGINS="http://localhost:5173"
uvicorn app:app --host 127.0.0.1 --port 8000
```

For local backend testing, `MODEL_LOAD_ON_STARTUP` defaults to false. The health endpoint works without loading a model. To load Qwen locally, install a compatible CUDA/PyTorch stack and set `MODEL_LOAD_ON_STARTUP=true`. For most users, use the Colab notebook instead.

## 3. Connect to Google Colab

1. Upload `GameForgeAI_Colab.ipynb` to Google Colab and open it.
2. In Colab, choose **Runtime → Change runtime type → T4 GPU** if available.
3. Run the notebook cells in order.
4. The notebook asks you to upload `GameForgeAI_Starter.zip`. Select the ZIP you downloaded.
5. It installs backend packages, loads Qwen in 4-bit, starts FastAPI in the same Colab process as the loaded model, and opens a temporary Cloudflare Tunnel.
6. Copy the displayed HTTPS tunnel URL.
7. In the GameForge AI frontend, open **Connection** and paste the URL and the API token printed by the notebook.

The tunnel URL changes when the Colab session restarts. The model and API stop when the Colab runtime disconnects.

## Security notes

- Treat the Colab tunnel URL and API token as secrets. Do not publish them.
- The frontend keeps the token only in in-memory React state; refreshing the page clears it.
- The tunnel is publicly reachable at the network layer. Bearer-token protection is not a substitute for a production access gateway, rate limiting, or user authentication. Use this setup only for your own trusted testing and stop the tunnel when finished.
- Do not expose a Colab session containing private files or credentials.
- Model-generated code is displayed as text. The starter does not execute generated code automatically.
- Do not add private API keys to frontend `.env` variables. Anything prefixed with `VITE_` is bundled into the browser.

## Important limitations

- This is a working starter, not a finished commercial game engine.
- The 2D/2.5D/3D preview panels are sample scenes to prove the UI pipeline; they do not yet import arbitrary generated game projects.
- Qwen may return prose, snippets, or code. The user must review generated code before integrating it into a project.
- Free Colab availability, GPU type, quotas, and session duration are controlled by Google and can change.
- The model is loaded with 4-bit NF4 quantization. Memory usage still depends on context length, generation length, other GPU processes, and the Colab runtime.

## Project layout

```text
GameForgeAI/
  frontend/
  backend/
  GameForgeAI_Colab.ipynb
  README.md
```
