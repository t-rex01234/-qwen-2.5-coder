import os
import json
import threading
from typing import Optional

import torch
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, TextIteratorStreamer

MODEL_ID = os.getenv("MODEL_ID", "Qwen/Qwen2.5-Coder-7B-Instruct")
API_TOKEN = os.getenv("GAMEFORGE_API_TOKEN", "")
CORS_ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if x.strip()]
LOAD_ON_STARTUP = os.getenv("MODEL_LOAD_ON_STARTUP", "false").lower() == "true"

app = FastAPI(title="GameForge AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

tokenizer = None
model = None
model_lock = threading.Lock()

class ChatRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
    max_new_tokens: int = Field(default=900, ge=1, le=1600)
    system_prompt: Optional[str] = Field(default=None, max_length=3000)

def require_auth(authorization: Optional[str]):
    if not API_TOKEN:
        raise HTTPException(status_code=503, detail="Backend API token is not configured.")
    expected = f"Bearer {API_TOKEN}"
    if authorization != expected:
        raise HTTPException(status_code=401, detail="Invalid or missing API token.")

def load_model():
    global tokenizer, model
    with model_lock:
        if model is not None:
            return
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA GPU not detected. Select a GPU runtime in Google Colab.")
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )
        tokenizer_local = AutoTokenizer.from_pretrained(MODEL_ID)
        model_local = AutoModelForCausalLM.from_pretrained(
            MODEL_ID,
            quantization_config=quant_config,
            device_map="auto",
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
        )
        model_local.eval()
        tokenizer, model = tokenizer_local, model_local

@app.on_event("startup")
def startup():
    if LOAD_ON_STARTUP:
        load_model()

@app.get("/health")
def health(authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    return {
        "ok": True,
        "model_id": MODEL_ID,
        "model_loaded": model is not None,
        "cuda_available": torch.cuda.is_available(),
    }

@app.post("/api/chat/stream")
def chat_stream(body: ChatRequest, authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    if model is None or tokenizer is None:
        raise HTTPException(status_code=503, detail="Model is not loaded. Check the Colab model-loading cell.")
    messages = []
    if body.system_prompt:
        messages.append({"role": "system", "content": body.system_prompt})
    else:
        messages.append({
            "role": "system",
            "content": "You are GameForge AI, a careful game-development coding assistant. Explain your plan briefly, produce maintainable code, state assumptions, and never claim code was executed or tested unless it actually was."
        })
    messages.append({"role": "user", "content": body.prompt})
    input_ids = tokenizer.apply_chat_template(
        messages, tokenize=True, add_generation_prompt=True, return_tensors="pt"
    ).to(model.device)
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)
    generation_kwargs = {
        "input_ids": input_ids,
        "streamer": streamer,
        "max_new_tokens": body.max_new_tokens,
        "do_sample": True,
        "temperature": 0.7,
        "top_p": 0.9,
        "repetition_penalty": 1.05,
    }
    def generate():
        try:
            with torch.inference_mode():
                model.generate(**generation_kwargs)
        except Exception as exc:
            streamer.on_finalized_text(f"\n[Generation error: {type(exc).__name__}: {exc}]", stream_end=True)
    thread = threading.Thread(target=generate, daemon=True)
    thread.start()

    def event_stream():
        try:
            for token in streamer:
                yield f"data: {json.dumps({'token': token})}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as exc:
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"
    return StreamingResponse(event_stream(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    })
